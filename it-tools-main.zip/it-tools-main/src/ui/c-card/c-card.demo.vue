<template>
  <div>
    <h2>Default</h2>

    <c-card title="Title">
      Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repudiandae ipsa reiciendis facilis officia nulla.
      Laboriosam cumque molestias excepturi doloribus nulla nemo quod ratione rerum possimus. Excepturi nihil possimus
      error itaque.
    </c-card>
  </div>
</template>
