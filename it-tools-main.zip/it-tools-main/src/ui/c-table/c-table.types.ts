export type HeaderConfiguration = (string | {
  key: string
  label?: string
})[] | Record<string, string>;
