export interface Ipv4RangeExpanderResult {
  oldSize?: number
  newStart?: string
  newEnd?: string
  newCidr?: string
  newSize?: number
}
