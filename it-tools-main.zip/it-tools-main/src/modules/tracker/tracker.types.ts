import type { createTrackerService } from './tracker.services';

export type TrackerService = ReturnType<typeof createTrackerService>;
